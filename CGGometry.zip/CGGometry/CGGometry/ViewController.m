//
//  ViewController.m
//  CGGometry
//
//  Created by 李春菲 on 16/10/19.
//  Copyright © 2016年 lichunfei. All rights reserved.
//

#import "ViewController.h"
#import "UIResponder+Adapt.h"
@interface ViewController ()
@property (strong,nonatomic) UIView * viewbackgroung;
@property (strong,nonatomic) UIImageView * image;


@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
//  CGPoint CGPointMakeAdapt(CGFloat x, CGFloat y);
    
    _viewbackgroung = [[UIView alloc]init];
    _viewbackgroung.backgroundColor = [UIColor redColor];
//    CGSize CGSizeMakeAdapt(CGFloat width, CGFloat height);
//    CGSizeMakeAdapt(200, 200);
    
    
    

//    CGRect CGRectMakeAdapt(CGFloat x, CGFloat y, CGFloat width, CGFloat height);
    _viewbackgroung.center = CGPointMakeAdapt(160,284);
    _viewbackgroung.bounds = CGRectMakeAdapt(0, 0, 40, 40);
//    _viewbackgroung. = CGSizeMakeAdapt(20, 20);
    [self.view addSubview:_viewbackgroung];
    
    
    UIView *view = [[UIView alloc]initWithFrame:CGRectMakeAdapt(180, 304, 50, 50)];
    view.backgroundColor = [UIColor blueColor];
    [self.view addSubview:view];
    
    
    NSLog(@"bgv~~%@,v~~~%@",NSStringFromCGRect(_viewbackgroung.frame),NSStringFromCGRect(view.frame));
//    _image = [[UIImageView alloc]init];
//    _image.backgroundColor = [UIColor yellowColor];
//   
//    CGSize image = CGSizeMakeAdapt(200, 200);
   
    
    
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
